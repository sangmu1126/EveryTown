import React from 'react';
import { Link } from 'react-router-dom';
import './NavigationBar.css'; // 상단 바에 대한 스타일

function NavigationBar() {
  return (
    <div className="navigation-bar">
      <Link to="/" className="MainPage">
        Every Town
      </Link>
      <div className="navigation-links">
        <Link to="/location" className="navigation-link">
          위치 설정
        </Link>
        <Link to="/login" className="navigation-link">
          로그인
        </Link>
      </div>
    </div>
  );
}

export default NavigationBar;
