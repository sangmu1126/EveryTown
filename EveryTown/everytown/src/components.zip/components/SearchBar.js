import React from 'react';
import './SearchBar.css'; // 검색 바 스타일을 별도로 관리하기 위한 CSS 파일

function SearchBar() {
  return (
    <div className="search-bar">
      <input type="text" placeholder="검색" />
    </div>
  );
}

export default SearchBar;
