import React from 'react';
import './Icon.css'; // 아이콘 스타일을 별도로 관리하기 위한 CSS 파일
import Food from '../assets/이미지/food_logo.png';
import Place from '../assets/이미지/place_logo.png';
import Chat from '../assets/이미지/chat_logo.png';
import Community from '../assets/이미지/community_logo.png';

function Icon({ type }) {
  let iconSrc;
  
  switch (type) {
    case 'Food':
      iconSrc = Food;
      break;
    case 'Place':
      iconSrc = Place;
      break;
    case 'Chat':
      iconSrc = Chat;
      break;
    case 'Community':
      iconSrc = Community;
      break;
    default:
      iconSrc = ''; 
  }

  return (
    <div className="icon">
      <img src={iconSrc} alt={type} />
    </div>
  );
}

export default Icon;
