// MainPage.js
import React from 'react';
import '../App.css';
import SearchBar from '../components/SearchBar';
import Icon from '../components/Icon';

const MainPage = () => {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Every Town</h1>
        <SearchBar />
        <div className="icons-container">
          <Icon type="Food" />
          <Icon type="Place" />
          <Icon type="Chat" />
          <Icon type="Community" />
        </div>  
      </header>
    </div>
  );
};

export default MainPage;
